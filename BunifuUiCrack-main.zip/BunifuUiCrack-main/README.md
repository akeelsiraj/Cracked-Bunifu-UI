# BunifuUiCrack
Bunifu UI Cracked
You can use this with the 6.0.0 version of the Bunifu UI Library.
(Or, you can use this with any version with Bunifu UI that **uses Bunifu.Licensing 5.0.0**)
## How to install?
1. Go to your project's folder (On Windows: C:\Users\yourusername\source\repo\ProjectName)
2. Find the packages folder (If you cant find it go one folder down it should be in the solution's folder)
3. Find Bunifu.Licensing.5.0.0
4. Overwrite the file.
5. Done! Enjoy


# if you want to contact me
discord: @t0int
telegram: @t0int
